import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'loginpage.dart';

class App extends StatefulWidget {

  const App({super.key});

  @override

  State<App> createState() => _AppState();

}

class _AppState extends State<App> {

  final TextEditingController email = TextEditingController();

  final TextEditingController password = TextEditingController();

  final TextEditingController userName = TextEditingController();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool hidePass1 = true;

  bool hidePass2 = true;

  String confirmPassword = "";

  Future<void> signup() async {

    if (!formKey.currentState!.validate()) return;

    if (password.text != confirmPassword) {

      ScaffoldMessenger.of(context).showSnackBar(

        const SnackBar(content: Text("Passwords do not match")),

      );

      return;

    }

    try {

      UserCredential cred =

      await FirebaseAuth.instance.createUserWithEmailAndPassword(

        email: email.text.trim(),

        password: password.text.trim(),

      );

      User? user = cred.user;

      if (user != null) {

        await FirebaseFirestore.instance

            .collection("pro")

            .doc(user.uid)

            .set({

          "uid": user.uid,

          "email": email.text.trim(),

          "username": userName.text.trim(),

          "createdAt": Timestamp.now(),

        });

        if (!user.emailVerified) {

          await user.sendEmailVerification();

        }

      }

      ScaffoldMessenger.of(context).showSnackBar(

        const SnackBar(content: Text("Account created successfully")),

      );

      Navigator.pop(context);

      email.clear();

      password.clear();

      userName.clear();

    } on FirebaseAuthException catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(content: Text(e.message ?? "Firebase error")),

      );

    }

  }

  @override

  Widget build(BuildContext context) {

    bool f1=true;

    bool f2=true;

    return Scaffold(

      backgroundColor: Colors.lightBlue.shade100,

      body: Stack(

        children: [

          Positioned.fill(

            child: Image.asset(

              'assets/background2.jpg',

              fit: BoxFit.cover,

            ),

          ),

          Center(

            child: Container(

              height: 520,

              width: 450,

              padding: const EdgeInsets.all(20),

              decoration: BoxDecoration(

                color: Colors.white70,

                borderRadius: BorderRadius.circular(20),

              ),

              child: Form(

                key: formKey,

                child: Column(

                  children: [

                    Text("Create Account" , style: TextStyle(color: Colors.indigo , fontSize: 25 ,fontWeight: FontWeight.bold),),

                    Text("Enter your information to sign up." , style: TextStyle(color: Colors.blueGrey , fontSize: 14),),

                    SizedBox(

                      height: 10,

                    ),

                    SizedBox(

                      height: 50,

                      width: 330,

                      child: TextFormField(

                        controller: userName,

                        validator: v1,

                        decoration: InputDecoration(

                          labelText: "User Name ",

                          prefixIcon: Icon(Icons.person ,color: Colors.indigo),

                          border: OutlineInputBorder(

                            borderRadius: BorderRadius.circular(15),

                          ),

                        ),

                      ),

                    ),

                    SizedBox(height: 10),


                    SizedBox(

                      height: 50,

                      width: 330,

                      child: TextFormField(

                        controller: email,

                        validator: v2,

                        decoration: InputDecoration(

                          labelText: "Email ",

                          prefixIcon: Icon(Icons.email ,color: Colors.indigo),

                          border: OutlineInputBorder(

                            borderRadius: BorderRadius.circular(15),

                          ),

                        ),

                      ),

                    ),

                    SizedBox(height: 10,),

                    SizedBox(

                      height: 50,

                      width: 330,

                      child:TextFormField(

                        controller: password,

                        validator: v3,

                        obscureText: hidePass1,

                        decoration: InputDecoration(

                          labelText: "Password",

                          prefixIcon: IconButton(

                            icon: Icon(hidePass1 ? Icons.lock : Icons.lock_open,

                                color: Colors.indigo),

                            onPressed: () {

                              setState(() {

                                hidePass1 = !hidePass1;

                              });

                            },

                          ),

                          border: OutlineInputBorder(

                            borderRadius: BorderRadius.circular(15),

                          ),

                        ),

                      ),

                    ),

                    SizedBox(

                      height: 10,

                    ),

                    SizedBox(

                      height: 50,

                      width: 330,

                      child: TextFormField(

                        onChanged: (value) {

                          confirmPassword = value;

                        },

                        validator: v3,

                        obscureText: hidePass2,

                        decoration: InputDecoration(

                          labelText: "Confirm password",

                          prefixIcon: IconButton(

                            icon: Icon(hidePass2 ? Icons.lock : Icons.lock_open,

                                color: Colors.indigo),

                            onPressed: () {

                              setState(() {

                                hidePass2 = !hidePass2;

                              });

                            },

                          ),

                          border: OutlineInputBorder(

                            borderRadius: BorderRadius.circular(15),

                          ),

                        ),

                      ),

                    ),                    SizedBox(height: 20),


                    TextButton(

                      onPressed: () {

                        Navigator.push(

                          context,

                          MaterialPageRoute(builder: (_) => const page2()),

                        );

                      },

                      child: const Text("Already have an account? Log in"),

                    ),
                    SizedBox(height: 20),

                    ElevatedButton(

                      style: ElevatedButton.styleFrom(

                        backgroundColor: Colors.orange,

                        minimumSize: const Size(300, 50),

                      ),

                      onPressed: signup,

                      child: const Text(

                        "Sign Up",

                        style: TextStyle(fontSize: 20, color: Colors.white),

                      ),

                    ),
                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("By signing up, you agree to our "),
                        Text("Terms " ,style: TextStyle(color: Colors.indigo),),
                        Text("and "),
                        Text("Privacy policy" ,style: TextStyle(color: Colors.indigo),),
                      ],
                    ),


                  ],

                ),

              ),

            ),

          ),

        ],

      ),

    );

  }

}

InputDecoration inputStyle(String label, IconData icon,

    [VoidCallback? onTap]) {

  return InputDecoration(

    labelText: label,

    prefixIcon: onTap == null

        ? Icon(icon, color: Colors.indigo)

        : IconButton(

      icon: Icon(icon, color: Colors.indigo),

      onPressed: onTap,

    ),

    border: OutlineInputBorder(

      borderRadius: BorderRadius.circular(15),

    ),

  );

}

String? v1(String? d) =>

    (d != null && d.length >= 3) ? null : "Name too short";

String? v2(String? d) =>

    (d != null && d.contains("@") && d.contains("."))

        ? null

        : "Invalid email";

String? v3(String? d) =>

    (d != null && d.length >= 6) ? null : "Password too short";
