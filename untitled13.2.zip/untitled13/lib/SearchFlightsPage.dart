import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Bookingsummary.dart';
import 'createAccount.dart';
import 'loginpage.dart';
import 'choosenow.dart';


class serach extends StatefulWidget {
  TextEditingController e;
  serach(this.e);

  @override
  State<serach> createState() => _serachState(e);
}

class _serachState extends State<serach> {
  TextEditingController em;
  List<String> a = [" "];
  String s1 =" ";
  String s2 =" ";
  String selected="1 Adult";
  _serachState(this.em) {
    Con();
  }

  Future<void> Con() async {
    String url = 'https://countriesnow.space/api/v0.1/countries';

    var l = Uri.parse(url);
    try {
      var j = await http.get(l);
      if (j.statusCode == 200) {
        setState(() {
          var t = jsonDecode(j.body);
          List b = [];
          b = t["data"];

          for (var x in b) a.add(x["country"].toString());
        });
      }
    } catch (h) {
      print(h.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return   Scaffold(
      body: Stack(children: [
        Positioned.fill(child: Image.asset('assets/background2.jpg',fit: BoxFit.cover,),),

        Center(child: Container(
          color: Color(0x80EAF3FF),
        )),
        SafeArea(child: Column(
          children: [
            Padding(padding:  EdgeInsets.symmetric(horizontal: 16,vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                      "SkyBook",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white,)

                  ),
                  Icon(
                    Icons.notifications_none,
                    color: Colors.blue,
                  ),

                ],),),
            Padding(padding: EdgeInsets.symmetric(horizontal: 16),
              child:Container(
                height: 600,
                width: 500,
                padding:EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Row(
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.arrow_left,
                              color: Colors.blue[900],
                            ),
                            onPressed: () {
                              Navigator.push(context,MaterialPageRoute(builder: (context)=>page2()));
                            },
                          ),
                          Text(
                            "Search Flights",
                            style: TextStyle(
                              fontSize: 24,
                              color: Colors.blue,

                              fontWeight: FontWeight.bold,
                            ),
                          ),

                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: Container(
                        height: 500,
                        width: 430,
                        padding:EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],

                        ),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [Icon(Icons.flight_takeoff ,color: Colors.blue),
                                SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      Text(
                                        "From",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      DropdownButton(value: s1,items: a.map<DropdownMenuItem<String>>((String h){
                                        return DropdownMenuItem(child: Text(h),value: h,);
                                      }).toList(), onChanged: (f){
                                        setState(() {
                                          s1=f!;
                                        });
                                      }),
                                      // Text(s1)
                                    ],),
                                )
                              ],),
                            SizedBox(height: 30),

                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [Icon(Icons.flight_land, color: Colors.blue),

                                SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      Text(
                                        "To",
                                        style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      DropdownButton(value: s2,items: a.map<DropdownMenuItem<String>>((String h){
                                        return DropdownMenuItem(child: Text(h),value: h,);
                                      }).toList(), onChanged: (f){
                                        setState(() {
                                          s2=f!;
                                        });
                                      }),
                                      // Text(s2),
                                    ],),
                                )
                              ],),

                            SizedBox(height: 30),
                            Row(children: [
                              Icon (Icons.calendar_month, color: Colors.blue),
                              Expanded(
                                child: TextField(
                                  decoration: InputDecoration(
                                    hintText: "2/2/2020",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                              ),
                            ],),
                            SizedBox(height: 30,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [Icon(Icons.person, color: Colors.blue),
                                SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      DropdownButton<String>(
                                        value: selected,
                                        isExpanded: true,
                                        items: const [
                                          DropdownMenuItem(value: "1 Adult", child: Text("1 Adult")),
                                          DropdownMenuItem(value: "5 Adult", child: Text("5 Adult")),
                                          DropdownMenuItem(value: "10 Adult", child: Text("10 Adult")),
                                        ],
                                        onChanged: (value) {
                                          setState(() {
                                            selected = value!;});
                                        },
                                      ),

                                    ],),
                                )
                              ],),
                            SizedBox(height: 40),

                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.orange ,minimumSize: Size(300, 50)),

                              onPressed: (){
                                Navigator.push(context,MaterialPageRoute(builder: (context) => choose(s1,s2,selected,em)));

                              }, child: Center(
                              child: Text("Search Flights",
                                style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white),),
                            ),)
                          ],),
                      ),),
                  ],),
              ),
            ),

          ],),

        )],),
    );
  }
}