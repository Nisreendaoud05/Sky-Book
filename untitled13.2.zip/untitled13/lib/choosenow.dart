import 'package:flutter/material.dart';
import 'SearchFlightsPage.dart';
import 'Bookingsummary.dart';

class choose extends StatefulWidget {
  String x;
  String y;
  String z;
  TextEditingController e;
  choose(this.x,this.y,this.z,this.e);

  @override
  State<choose> createState() => _chooseState(x,y,z,e);
}

class _chooseState extends State<choose> {
  String xx;
  String yy;
  String zz;
  TextEditingController em;
  _chooseState(this.xx,this.yy,this.zz,this.em);
  String selectedFilter = 'Price';

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body: Stack(children: [
          Positioned.fill(child: Image.asset('assets/background2.jpg',fit: BoxFit.cover,),),
          Center(
            child: Container(
              color: Color(0x80EAF3FF),),),
          SafeArea(child: Column(
            children: [
              Padding(padding:  EdgeInsets.symmetric(horizontal: 16,vertical: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                        "SkyBook",
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white,)
                    ),
                    Icon(
                      Icons.notifications_none,
                      color: Colors.blue,
                    ),

                  ],),),

              Padding(padding: EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  height: 630,
                  width: 450,
                  padding:EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Center(
                        child:Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(onPressed: (){
                              setState(() {
                                Navigator.pop(context);
                              });
                            }, icon: Icon(  Icons.arrow_left,
                            )),
                            Text(
                              xx+ " --→  " +yy,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[900],
                              ),
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.tune,
                                color: Colors.blue[900],
                              ),
                              onPressed: () {
                              },
                            ),
                          ],
                        ),

                      ),Row(
                        children: [
                          DropdownButton<String>(
                            value: selectedFilter,
                            items: const [
                              DropdownMenuItem(value: 'Price', child: Text('Price',style: TextStyle(color: Colors.orange),)),
                            ],
                            onChanged: (value) {
                              setState(() {
                                selectedFilter = value!;
                              });
                            },
                          ),
                          SizedBox(width: 20),

                          DropdownButton<String>(
                            value: selectedFilter,
                            items: const [
                              DropdownMenuItem(value: 'Price', child: Text('Duration',style: TextStyle(color: Colors.black))),
                            ],
                            onChanged: (value) {
                              setState(() {
                                selectedFilter = value!;
                              });
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 20,
                        width: 20,),
                      Container(
                        width: 400,
                        height: 150,
                        decoration: BoxDecoration(
                          color: Colors.white,

                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(children: [
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              children: [Image.asset('assets/pic.png',height: 40,width: 40,),
                                SizedBox(width: 20,),
                                Text("Emirates",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                                SizedBox(width: 170,),
                                Text("\$ 320 ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              ],

                            ),
                          ),SizedBox(width: 10,),
                          Row(
                            children: [
                              SizedBox(width: 5),
                              Text("Time",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              SizedBox(width: 27,),

                              Text("10.00---> 13.45"),
                              SizedBox(width: 100,),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange),

                                onPressed: (){
                                  setState(() {
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=> Search(xx, yy, zz, em)
                                    ));
                                  });
                                }, child: Center(
                                child: Text("Book Now ",
                                  style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: Colors.white),),
                              ),)

                            ],

                          ),
                          Text("2hr 45min", style: TextStyle( color: Colors.grey[500],
                          ),)
                        ],),
                      ) ,
                      SizedBox(height: 20,),
                      Container(
                        width: 400,
                        height: 150,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(children: [
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              children: [Image.asset('assets/pic2.png',height: 40,width: 40,),
                                SizedBox(width: 20,),
                                Text("Qatar Airways ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                                SizedBox(width: 170,),
                                Text("\$ 280 ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              ],

                            ),
                          ),SizedBox(width: 10,),
                          Row(
                            children: [
                              SizedBox(width: 5),
                              Text("Time",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              SizedBox(width: 27,),

                              Text("15.00- --> 18.30"),
                              SizedBox(width: 100,),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange),

                                onPressed: (){

                                }, child: Center(
                                child: Text("Book Now ",
                                  style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: Colors.white),),
                              ),)

                            ],

                          ),
                          Text("2hr 30min", style: TextStyle( color: Colors.grey[500],
                          ),)
                        ],),
                      ) ,
                      SizedBox(height: 20,),
                      Container(
                        width: 400,
                        height: 150,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(children: [
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              children: [Image.asset('assets/pic4.png',height: 40,width: 40,),
                                SizedBox(width: 20,),
                                Text("Flydubai ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                                SizedBox(width: 170,),
                                Text("\$ 260 ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              ],

                            ),
                          ),SizedBox(width: 10,),
                          Row(
                            children: [
                              SizedBox(width: 5),
                              Text("Time",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              SizedBox(width: 27,),

                              Text("9.30- --> 13.00"),
                              SizedBox(width: 100,),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange),

                                onPressed: (){

                                }, child: Center(
                                child: Text("Book Now ",
                                  style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: Colors.white),),
                              ),)

                            ],

                          ),
                          Text("9hr 30min", style: TextStyle( color: Colors.grey[500],
                          ),)
                        ],),
                      ) ,





                    ],),
                ),

              ),


            ],
          ))
        ],)
    );  }
}