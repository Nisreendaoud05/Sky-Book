import 'package:flutter/material.dart';
import 'choosenow.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Search extends StatefulWidget {
  String x;
  String y;
  String z;
  TextEditingController e;
  Search(this.x,this.y,this.z,this.e);
  @override
  State<Search> createState() => _SearchState(x,y,z,e);
}

class _SearchState extends State<Search> {

  String xx;
  String yy;
  String zz;
  TextEditingController em;
  _SearchState(this.xx,this.yy,this.zz,this.em);
  int selectedValue = 1;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Positioned.fill(child: Image.asset('assets/background2.jpg',fit: BoxFit.cover,),),
        Center(child: Container(

          color: Color(0x80EAF3FF),
        ),
        ),
        SafeArea(child: Column(children: [
          Padding(padding:  EdgeInsets.symmetric(horizontal: 16,vertical: 12),
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                    "SkyBook",
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white,)
                ),
                Icon(
                  Icons.notifications_none,
                  color: Colors.blue,
                ),

              ],),),

          Padding(padding: EdgeInsets.symmetric(horizontal: 16),

            child: Container( height: 600,
              width: 400,
              padding:EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [

                  Center(child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.arrow_left,
                          color: Colors.blue[900],
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                      Text(
                        "BooKing Summary",style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue[900],
                      ),
                      ),

                    ],
                  ),),
                  SizedBox(width: 50,),
                  Container(
                    width: 350,
                    height: 220,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(children: [
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          children: [Image.asset('assets/pic.png',height: 40,width: 40,),
                            SizedBox(width: 20,),
                            Text("Emirates",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                            SizedBox(width: 140,),
                            Text("\$ 320 ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                          ],

                        ),
                      ),SizedBox(width: 50,),
                      Row(
                        children: [
                          SizedBox(width: 5),
                          Text("Time",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                          SizedBox(width: 27,),

                          Text("10.00 ---> 13.45"),
                          SizedBox(width: 27,),

                        ],

                      ),
                      Text("2hr 45min", style: TextStyle( color: Colors.grey[500],
                      ),),
                      SizedBox(height: 20,),

                      Row(children: [
                        SizedBox(width: 10,),

                        Text("Flight Details")
                      ],),
                      SizedBox(width: 10,),

                      Row(children: [
                        SizedBox(width: 10,),

                        Text("Form:",style: TextStyle( color: Colors.grey[400],

                        ),),
                        Text(xx+" -10:00 ")
                      ],),
                      SizedBox(width: 20,),

                      Row(children: [
                        SizedBox(width: 10,),

                        Text("  To :",style: TextStyle( color: Colors.grey[400],),),
                        Text( yy+" -13:45")
                      ],),
                      Row(
                        children: [
                          SizedBox(width: 10,),
                          Text("Flight : Non- Stop | 25hr 45min ",style: TextStyle( color: Colors.grey[400],
                          ),),

                        ],
                      )

                    ],),
                  ),
                  SizedBox(height: 10,),
                  Container(
                    width: 350,
                    height: 90,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child:
                    Column(
                      children: [

                        Row(children: [
                          SizedBox(width: 10,height: 10,),

                          Text("Passenger Info",style: TextStyle( color: Colors.grey[600],
                          ),),



                        ],),


                        Row(
                          children: [
                            SizedBox(width: 10),
                            Icon(Icons.account_circle),
                            SizedBox(width: 10),
                            StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection("pro")
                                  .where("email", isEqualTo: widget.e.text.trim())
                                  .snapshots(),
                              builder: (context, snapshot) {
                                if (!snapshot.hasData) {
                                  return Text("Loading...", style: TextStyle(color: Colors.grey[700]));
                                }
                                final docs = snapshot.data!.docs;
                                if (docs.isEmpty) {
                                  return Text("User not found", style: TextStyle(color: Colors.grey[700]));
                                }

                                final username = docs.first["username"];
                                return Column(
                                  children: [
                                    Text(
                                      username,
                                      style: TextStyle(color: Colors.grey[700], fontWeight: FontWeight.bold),
                                    ),
                                    Text(zz)
                                  ],
                                );
                                
                              },
                            ),
                          ],
                        ),



                      ],

                    ),),
                  SizedBox(height: 10,),

                  Container( width: 350,
                    height: 90,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ), child:    Column(
                        children: [

                          Row(children: [
                            SizedBox(width: 10,height: 10,),

                            Text("Payment Method",style: TextStyle( color: Colors.grey[600],
                            ),),

                          ],),
                          Row(
                            children: [
                              SizedBox(width: 10),

                              Image.asset('assets/pic4.png',height: 40,width: 40,),
                              Text("  Visa ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                              Text(" ***** 5678  ",style: TextStyle(color: Colors.grey[600],)),
                              SizedBox(width: 140),

                              Radio<int>(
                                value: 1,
                                groupValue: selectedValue,
                                activeColor: Colors.orange,
                                onChanged: ( int ? c) {
                                  setState(() {
                                    selectedValue = c!;
                                  });
                                },
                              )

                            ],
                          ),
                        ]),),
                  SizedBox(height: 10,),

                  Container( width: 350,
                    height: 80,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Row(

                          children: [
                            SizedBox(width: 10),

                            Text("Total Price",style: TextStyle( color: Colors.grey[600])),
                            SizedBox(width: 200),
                            Text("\$ 320.00 ",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black)),
                          ],

                        ),
                        SizedBox(height: 20,),

                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange),

                          onPressed: (){
                            ScaffoldMessenger.of(
                              context,
                            ).showSnackBar(SnackBar(content: Text("the ticket has been sent to your email")));
                          }, child: Center(
                          child: Text("Confirm and pay ",
                            style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
                        ),)

                      ],
                    ),


                  ),






                ],

              ),
            ),
          )



        ],))
      ],),
    );
  }
}