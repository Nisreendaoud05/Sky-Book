import 'package:flutter/material.dart';
import 'loginpage.dart';
import 'createAccount.dart';

class first extends StatefulWidget {
  const first({super.key});

  @override
  State<first> createState() => _MyAppState();
}

class _MyAppState extends State<first> with SingleTickerProviderStateMixin {
  late AnimationController c;
  late Animation<Offset> s;
  late Animation<double> f;
  late Animation<double> text;

  @override
  void initState() {
    super.initState();

    c = AnimationController(vsync: this, duration: Duration(seconds: 1));

    s = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(0, -1),
    ).animate(CurvedAnimation(parent: c, curve: Curves.easeIn));

    f = Tween<double>(
      begin: 1,
      end: 0,
    ).animate(CurvedAnimation(parent: c, curve: Curves.easeOut));

    text = Tween<double>(
      begin: 1,
      end: 0,
    ).animate(CurvedAnimation(parent: c, curve: Curves.easeIn));
  }

  void startAnimation() async {
    await c.forward();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const page2()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/background3.png', fit: BoxFit.cover),
          ),

          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SlideTransition(
                  position: s,
                  child: FadeTransition(
                    opacity: f,
                    child:  Icon(
                      Icons.flight,
                      size: 100,
                      color: Colors.white,
                    ),
                  ),
                ),

                SizedBox(height: 20),
                FadeTransition(
                  opacity: text,
                  child: Text(
                    "SkyBook",
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),

                SizedBox(height: 15),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: startAnimation,
                  child: Text("Ready to Fly"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}