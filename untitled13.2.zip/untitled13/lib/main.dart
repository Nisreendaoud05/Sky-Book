import 'package:flutter/material.dart';
import 'SearchFlightsPage.dart';
import 'createaccount.dart';
import 'choosenow.dart';
import 'loginpage.dart';
import 'Firstpage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MaterialApp(
      home: first(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
