import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'Bookingsummary.dart';
import 'createAccount.dart';
import 'SearchFlightsPage.dart';

class page2 extends StatefulWidget {
  const page2({super.key});

  @override
  State<page2> createState() => _page2State();
}

class _page2State extends State<page2> {

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();


  Future<void> login(BuildContext c) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.text.trim(),
        password: password.text.trim(),
      );
      User? u = FirebaseAuth.instance.currentUser;
      if (u != null && !u.emailVerified)
        await FirebaseAuth.instance.signOut();
      else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Correct")));
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => serach(email)),
        );
        //email.clear();
        password.clear();
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  String t1 = "";
  String t2 = "";
  final k = GlobalKey<FormState>();
  bool f1 = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue.shade100,
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/background2.jpg',fit: BoxFit.cover,),),
          Center(
            child: Column(
              children: [
                SizedBox(height: 70),
                Container(
                  height: 500,
                  width: 450,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white70,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Center(
                      child: Form(
                        key: k,
                        child: Column(
                          children: [
                            SizedBox(height: 50),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.airplanemode_on_rounded,
                                  size: 40,
                                  color: Colors.indigo,
                                ),
                                Text(
                                  "SkyBook",
                                  style: TextStyle(
                                    fontSize: 30,
                                    color: Colors.indigo,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 20),
                            Text(
                              "Enter your email and password ",
                              style: TextStyle(
                                color: Colors.black45,
                                fontSize: 12,
                              ),
                            ),

                            SizedBox(height: 20),
                            SizedBox(
                              height: 50,
                              width: 330,
                              child: TextFormField(
                                controller: email,
                                //validator: v1,
                                decoration: InputDecoration(
                                  labelText: "Email ",
                                  prefixIcon: Icon(Icons.email ,color: Colors.indigo),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                onChanged: (f) {
                                  setState(() {
                                    t1 = f!;
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 15),
                            SizedBox(
                              height: 50,
                              width: 330,
                              child: TextFormField(
                                controller: password,
                                // validator: v2,
                                obscureText: f1,
                                decoration: InputDecoration(
                                  labelText: "Password ",
                                  prefixIcon: IconButton(
                                    icon: Icon(f1? Icons.lock:Icons.lock_open,color : Colors.indigo,),
                                    onPressed: () {
                                      setState(() {
                                        f1 = !f1;

                                      });
                                    },
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                onChanged: (f) {
                                  setState(() {
                                    t2 = f!;
                                  });
                                },
                              ),
                            ),
                            SizedBox(height: 20),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                                shadowColor: Colors.black,
                                minimumSize: Size(300, 50),
                              ),
                              onPressed: () {
                                setState(() {
                                  login(context);
                                 Navigator.push(context, MaterialPageRoute(builder: (context)=> serach(email)));
                                });
                             },
                              child: Text(
                                "Login",
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            SizedBox(height: 30),
                            Text("Don't have an account ?" , style: TextStyle(color: Colors.black45),),
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=> App()));
                                });
                              },
                              child: Text("Create account"),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }
}


/*String? v1(String? d) {
  if (d != null && d.length >= 10 && d.contains(".") && d.contains("@")) {
    return null;
  } else
    return "length <10 or null or not contains . or @ ";
}

String? v2(String? d) {
  if (d != null && d.length >= 10) {
    return null;
  } else
    return "length <10 or null ";
}*/